student_name = "abc def"
program = "PIAIC"
fathers_name = "bbb ccc"
age = 26
score = 200

info = """
PIAIC Islamabad Batch 3
Name : {student_name}
Father's Name : {fathers_name}
Age : {age}
Score : {score}
Program Name : {program}
"""

print(info)